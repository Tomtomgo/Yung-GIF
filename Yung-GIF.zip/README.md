# Yung GIF 😱
- - - 
Killer lifestyle & happiness productivity tool: all new GIFs under one button.

## Installing 

### Via Chrome Web Store 😚
- - - 
1. https://chrome.google.com/webstore/detail/yung-gif/pcbjhjfodgcbadhdpponooolomfhlamg

### Manually 😩
- - - 
1. put all files in folder $folder_name
2. goto chrome://extensions
3. click developer mode, 'load unpacked extension...'
4. find $folder_name, click ok, enable Yung GIF
